# Pico SDK SD Card bindings for Fat FS

All of the hard work to bring up these bindings was done by @elohobica - https://github.com/elehobica/pico_fatfs_test

`sdcard.c` is a hard fork of their `tf_card.c` to add re-usable SDCard support to the Pimoroni Pico libraries.

It's licensed under the BSD 2-Clause license.
